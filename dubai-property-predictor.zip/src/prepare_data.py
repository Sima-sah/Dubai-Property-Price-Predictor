"""
Cleans the raw DLD transaction export and engineers features for modeling.

Usage:
    python src/prepare_data.py --input data/transactions.csv --output data/processed.csv
"""
import argparse
import numpy as np
import pandas as pd


NUMERIC_COLS = [
    "Amount", "Transaction Size (sq.m)", "Property Size (sq.m)",
    "Room(s)", "Parking", "Nearest Metro", "Nearest Mall", "Nearest Landmark",
    "No. of Buyer", "No. of Seller",
]

CATEGORICAL_COLS = [
    "Transaction Type", "Transaction sub type", "Registration type",
    "Is Free Hold?", "Usage", "Area", "Property Type", "Property Sub Type",
]

MIN_PRICE = 50_000        # drop obviously bad/placeholder rows
MAX_PRICE = 200_000_000   # drop extreme outlier mansions/land parcels
MIN_SIZE = 10


def load_raw(path: str) -> pd.DataFrame:
    df = pd.read_csv(path, low_memory=False)
    df.columns = [c.strip() for c in df.columns]
    return df


def clean(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()

    # keep sales only — mortgages/gifts don't reflect market price
    if "Transaction Type" in df.columns:
        df = df[df["Transaction Type"].astype(str).str.contains("Sales", case=False, na=False)]

    for col in NUMERIC_COLS:
        if col in df.columns:
            df[col] = pd.to_numeric(df[col], errors="coerce")

    # parse date -> year/month/quarter (captures market cycles, seasonality)
    if "Transaction Date" in df.columns:
        df["Transaction Date"] = pd.to_datetime(df["Transaction Date"], errors="coerce", dayfirst=True)
        df["tx_year"] = df["Transaction Date"].dt.year
        df["tx_month"] = df["Transaction Date"].dt.month
        df["tx_quarter"] = df["Transaction Date"].dt.quarter

    # drop rows with missing essentials
    essential = ["Amount", "Property Size (sq.m)", "Area", "Property Type"]
    essential = [c for c in essential if c in df.columns]
    df = df.dropna(subset=essential)

    # sane bounds
    df = df[(df["Amount"] >= MIN_PRICE) & (df["Amount"] <= MAX_PRICE)]
    df = df[df["Property Size (sq.m)"] >= MIN_SIZE]

    # engineered features
    df["price_per_sqm"] = df["Amount"] / df["Property Size (sq.m)"]

    # collapse rare categories (long-tail Area/Project values hurt one-hot models)
    for col in ["Area", "Project", "Master Project"]:
        if col in df.columns:
            counts = df[col].value_counts()
            rare = counts[counts < 20].index
            df[col] = df[col].where(~df[col].isin(rare), other="Other")

    # winsorize price_per_sqm to remove residual noise/typos
    lo, hi = df["price_per_sqm"].quantile([0.01, 0.99])
    df = df[(df["price_per_sqm"] >= lo) & (df["price_per_sqm"] <= hi)]

    # log target — Amount is heavily right-skewed
    df["log_amount"] = np.log1p(df["Amount"])

    keep_cols = [c for c in NUMERIC_COLS + CATEGORICAL_COLS
                 if c in df.columns and c != "Amount"]
    keep_cols += ["tx_year", "tx_month", "tx_quarter", "log_amount", "Amount"]
    if "Area" in df.columns:
        keep_cols.append("Area")
    keep_cols = list(dict.fromkeys([c for c in keep_cols if c in df.columns]))

    return df[keep_cols].reset_index(drop=True)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--input", required=True)
    ap.add_argument("--output", required=True)
    args = ap.parse_args()

    df = load_raw(args.input)
    print(f"Loaded {len(df):,} raw rows")
    processed = clean(df)
    print(f"Kept {len(processed):,} rows after cleaning ({len(processed)/len(df):.1%})")
    processed.to_csv(args.output, index=False)
    print(f"Saved cleaned data to {args.output}")


if __name__ == "__main__":
    main()
