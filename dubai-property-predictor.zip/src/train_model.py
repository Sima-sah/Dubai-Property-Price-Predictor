"""
Trains a gradient-boosted regression model to predict Dubai property prices
(log-transformed), evaluates it, and saves the model + preprocessing pipeline.

Usage:
    python src/train_model.py --input data/processed.csv
"""
import argparse
import json
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_absolute_error, r2_score, mean_absolute_percentage_error
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder

NUMERIC_FEATURES = [
    "Transaction Size (sq.m)", "Property Size (sq.m)", "Room(s)", "Parking",
    "Nearest Metro", "Nearest Mall", "Nearest Landmark",
    "No. of Buyer", "No. of Seller", "tx_year", "tx_month", "tx_quarter",
]
CATEGORICAL_FEATURES = [
    "Registration type", "Is Free Hold?", "Usage", "Area",
    "Property Type", "Property Sub Type",
]


def build_pipeline(numeric_cols, categorical_cols):
    preprocessor = ColumnTransformer(transformers=[
        ("num", "passthrough", numeric_cols),
        ("cat", OneHotEncoder(handle_unknown="ignore"), categorical_cols),
    ])
    model = RandomForestRegressor(
        n_estimators=400,
        max_depth=18,
        min_samples_leaf=3,
        n_jobs=-1,
        random_state=42,
    )
    return Pipeline([("preprocess", preprocessor), ("model", model)])


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--input", required=True)
    ap.add_argument("--model-out", default="models/model.pkl")
    args = ap.parse_args()

    df = pd.read_csv(args.input)

    numeric_cols = [c for c in NUMERIC_FEATURES if c in df.columns]
    categorical_cols = [c for c in CATEGORICAL_FEATURES if c in df.columns]
    df = df.dropna(subset=numeric_cols + categorical_cols + ["log_amount"])

    X = df[numeric_cols + categorical_cols]
    y = df["log_amount"]

    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    pipe = build_pipeline(numeric_cols, categorical_cols)
    pipe.fit(X_train, y_train)

    pred_log = pipe.predict(X_test)
    pred = np.expm1(pred_log)
    actual = np.expm1(y_test)

    mae = mean_absolute_error(actual, pred)
    mape = mean_absolute_percentage_error(actual, pred)
    r2 = r2_score(actual, pred)

    print("\n=== Evaluation on held-out test set ===")
    print(f"R^2:  {r2:.3f}")
    print(f"MAE:  AED {mae:,.0f}")
    print(f"MAPE: {mape:.1%}")

    # feature importance (on the fitted RandomForest, mapped back to encoded names)
    ohe = pipe.named_steps["preprocess"].named_transformers_["cat"]
    encoded_cat_names = list(ohe.get_feature_names_out(categorical_cols))
    all_feature_names = numeric_cols + encoded_cat_names
    importances = pipe.named_steps["model"].feature_importances_
    top = sorted(zip(all_feature_names, importances), key=lambda x: -x[1])[:15]
    print("\n=== Top 15 features ===")
    for name, imp in top:
        print(f"{name:40s} {imp:.4f}")

    Path("models").mkdir(exist_ok=True)
    joblib.dump({
        "pipeline": pipe,
        "numeric_cols": numeric_cols,
        "categorical_cols": categorical_cols,
        "categories": {c: sorted(df[c].dropna().unique().tolist()) for c in categorical_cols},
        "metrics": {"r2": r2, "mae": mae, "mape": mape},
    }, args.model_out)
    print(f"\nSaved trained model to {args.model_out}")


if __name__ == "__main__":
    main()
