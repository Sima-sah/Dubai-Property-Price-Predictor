"""
Generates data/sample_transactions.csv — a synthetic dataset with the SAME
column schema as the real Dubai Land Department transaction export, so you
can test the full pipeline before downloading real data.

This is NOT real data. Replace data/transactions.csv with the actual DLD
export before training a model you'd show off.
"""
import numpy as np
import pandas as pd
from pathlib import Path

rng = np.random.default_rng(42)
N = 3000

areas = [
    "Business Bay", "Downtown Dubai", "Dubai Marina", "Jumeirah Lake Towers",
    "Palm Jumeirah", "Al Barsha", "Jumeirah Village Circle", "Dubai Silicon Oasis",
    "Arabian Ranches", "Dubai Sports City", "Al Furjan", "Dubai Hills Estate",
]
# rough relative price-per-sqm tier by area, purely for making synthetic data realistic
area_tier = {a: t for a, t in zip(areas, [1.3, 1.6, 1.5, 1.1, 2.0, 0.9, 0.85, 0.8, 1.0, 0.85, 0.9, 1.2])}

property_types = ["Unit", "Building", "Land"]
property_sub_types = ["Flat", "Villa", "Office", "Shop", "Warehouse"]
usages = ["Residential", "Commercial", "Other"]
reg_types = ["Ready", "Off Plan"]

dates = pd.date_range("2019-01-01", "2026-08-01", freq="D")

rows = []
for i in range(N):
    area = rng.choice(areas)
    tier = area_tier[area]
    ptype = rng.choice(property_types, p=[0.75, 0.1, 0.15])
    sub = rng.choice(property_sub_types)
    usage = rng.choice(usages, p=[0.75, 0.2, 0.05])
    size_sqm = max(30, rng.normal(110, 60))
    rooms = int(np.clip(rng.poisson(2), 0, 6))
    free_hold = rng.choice(["Yes", "No"], p=[0.8, 0.2])
    reg = rng.choice(reg_types, p=[0.65, 0.35])
    metro_dist = round(abs(rng.normal(1.5, 1.2)), 2)
    mall_dist = round(abs(rng.normal(2.0, 1.5)), 2)

    base_price_per_sqm = rng.normal(14000, 2500) * tier
    price = base_price_per_sqm * size_sqm
    price *= 1 + (0.05 if reg == "Ready" else -0.03)
    price *= 1 + (0.15 if usage == "Commercial" else 0)
    price = max(150000, price + rng.normal(0, price * 0.08))

    rows.append({
        "Transaction Number": f"TX-{100000+i}",
        "Transaction Date": pd.Timestamp(rng.choice(dates)).strftime("%d-%m-%Y"),
        "Transaction Type": "Sales",
        "Transaction sub type": "Sell",
        "Registration type": reg,
        "Is Free Hold?": free_hold,
        "Usage": usage,
        "Area": area,
        "Property Type": ptype,
        "Property Sub Type": sub,
        "Amount": round(price, 0),
        "Transaction Size (sq.m)": round(size_sqm, 1),
        "Property Size (sq.m)": round(size_sqm, 1),
        "Room(s)": rooms,
        "Parking": rng.choice([0, 1, 2]),
        "Nearest Metro": metro_dist,
        "Nearest Mall": mall_dist,
        "Nearest Landmark": round(abs(rng.normal(3, 2)), 2),
        "No. of Buyer": rng.choice([1, 2], p=[0.85, 0.15]),
        "No. of Seller": rng.choice([1, 2], p=[0.9, 0.1]),
        "Master Project": f"{area} Community",
        "Project": f"{area} Tower {rng.integers(1, 20)}",
    })

df = pd.DataFrame(rows)
out = Path(__file__).resolve().parents[1] / "data" / "sample_transactions.csv"
out.parent.mkdir(exist_ok=True)
df.to_csv(out, index=False)
print(f"Wrote {len(df)} synthetic rows to {out}")
