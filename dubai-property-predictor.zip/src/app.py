"""
Live Streamlit app: Dubai Property Price Predictor
Run: streamlit run src/app.py
"""
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
import plotly.express as px
import streamlit as st

MODEL_PATH = Path(__file__).resolve().parents[1] / "models" / "model.pkl"
PROCESSED_PATH = Path(__file__).resolve().parents[1] / "data" / "processed.csv"

st.set_page_config(page_title="Dubai Property Price Predictor", page_icon="🏙️", layout="centered")

st.title("🏙️ Dubai Property Price Predictor")
st.caption(
    "Trained on real Dubai Land Department transaction data. "
    "Estimates a fair sale price given property characteristics."
)

if not MODEL_PATH.exists():
    st.error(
        "No trained model found. Run this first:\n\n"
        "```\npython src/prepare_data.py --input data/transactions.csv --output data/processed.csv\n"
        "python src/train_model.py --input data/processed.csv\n```"
    )
    st.stop()

bundle = joblib.load(MODEL_PATH)
pipe = bundle["pipeline"]
numeric_cols = bundle["numeric_cols"]
categorical_cols = bundle["categorical_cols"]
categories = bundle["categories"]
metrics = bundle["metrics"]

with st.sidebar:
    st.subheader("Model performance")
    st.metric("R²", f"{metrics['r2']:.3f}")
    st.metric("MAE", f"AED {metrics['mae']:,.0f}")
    st.metric("MAPE", f"{metrics['mape']:.1%}")
    st.caption("Evaluated on a held-out 20% test split.")

st.subheader("Describe the property")

col1, col2 = st.columns(2)
with col1:
    area = st.selectbox("Area", categories.get("Area", ["Business Bay"]))
    property_type = st.selectbox("Property Type", categories.get("Property Type", ["Unit"]))
    property_sub_type = st.selectbox("Property Sub Type", categories.get("Property Sub Type", ["Flat"]))
    usage = st.selectbox("Usage", categories.get("Usage", ["Residential"]))
with col2:
    size_sqm = st.number_input("Property Size (sq.m)", min_value=15.0, max_value=2000.0, value=100.0, step=5.0)
    rooms = st.number_input("Room(s)", min_value=0, max_value=10, value=2)
    reg_type = st.selectbox("Registration type", categories.get("Registration type", ["Ready"]))
    free_hold = st.selectbox("Freehold?", categories.get("Is Free Hold?", ["Yes"]))

with st.expander("Advanced (optional)"):
    parking = st.number_input("Parking spots", min_value=0, max_value=5, value=1)
    metro_dist = st.number_input("Distance to nearest metro (km)", min_value=0.0, value=1.5, step=0.1)
    mall_dist = st.number_input("Distance to nearest mall (km)", min_value=0.0, value=2.0, step=0.1)
    landmark_dist = st.number_input("Distance to nearest landmark (km)", min_value=0.0, value=3.0, step=0.1)
    n_buyers = st.number_input("No. of buyers", min_value=1, max_value=5, value=1)
    n_sellers = st.number_input("No. of sellers", min_value=1, max_value=5, value=1)
    tx_year = st.number_input("Transaction year", min_value=2015, max_value=2030, value=2026)
    tx_month = st.number_input("Transaction month", min_value=1, max_value=12, value=6)

if st.button("Predict price", type="primary", use_container_width=True):
    row = {
        "Transaction Size (sq.m)": size_sqm,
        "Property Size (sq.m)": size_sqm,
        "Room(s)": rooms,
        "Parking": parking,
        "Nearest Metro": metro_dist,
        "Nearest Mall": mall_dist,
        "Nearest Landmark": landmark_dist,
        "No. of Buyer": n_buyers,
        "No. of Seller": n_sellers,
        "tx_year": tx_year,
        "tx_month": tx_month,
        "tx_quarter": (tx_month - 1) // 3 + 1,
        "Registration type": reg_type,
        "Is Free Hold?": free_hold,
        "Usage": usage,
        "Area": area,
        "Property Type": property_type,
        "Property Sub Type": property_sub_type,
    }
    X = pd.DataFrame([row])[numeric_cols + categorical_cols]
    pred_log = pipe.predict(X)[0]
    pred_price = np.expm1(pred_log)

    st.success(f"### Estimated price: AED {pred_price:,.0f}")
    st.caption(f"≈ AED {pred_price/size_sqm:,.0f} per sq.m — typical MAPE for this model is {metrics['mape']:.0%}, treat as an estimate, not a valuation.")

    if PROCESSED_PATH.exists():
        hist = pd.read_csv(PROCESSED_PATH)
        hist_area = hist[hist["Area"] == area]
        if len(hist_area) > 5:
            fig = px.histogram(hist_area, x="price_per_sqm", nbins=30,
                                title=f"Price per sq.m distribution — {area}")
            fig.add_vline(x=pred_price / size_sqm, line_color="red",
                          annotation_text="Your estimate")
            st.plotly_chart(fig, use_container_width=True)

st.divider()
st.caption(
    "Data: Dubai Land Department open data (dubailand.gov.ae / Dubai Pulse). "
    "Built as a portfolio project — not financial or investment advice."
)
