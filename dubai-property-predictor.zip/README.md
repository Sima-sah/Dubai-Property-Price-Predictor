# Dubai Property Price Predictor

Predicts Dubai real-estate transaction prices using official Dubai Land
Department (DLD) transaction data. Built as a portfolio / CV project —
real government data, a proper ML pipeline, and a live deployable app.

## 1. Get the real data (you do this once, ~2 minutes)

1. Go to **https://dubailand.gov.ae/en/open-data/real-estate-data/**
2. Under the **Transactions** tab, set:
   - From Date: e.g. `01-01-2019`
   - To Date: today's date
   - Leave other filters as "All" (or narrow to Residential + Unit if you
     want a cleaner first pass)
3. Solve the captcha, click **Search**, then **Download as CSV**.
4. For a bigger historical set (millions of rows back to ~2004), also grab
   the bulk file from **Dubai Pulse**:
   https://www.dubaipulse.gov.ae/data/dld-transactions/dld_transactions-open
5. Save whichever file(s) you get as:
   `data/transactions.csv`

The column names DLD uses (already wired into the code below):
`Transaction Number, Transaction Date, Transaction Type, Transaction sub type,
Registration type, Is Free Hold?, Usage, Area, Property Type, Property Sub Type,
Amount, Transaction Size (sq.m), Property Size (sq.m), Room(s), Parking,
Nearest Metro, Nearest Mall, Nearest Landmark, No. of Buyer, No. of Seller,
Master Project, Project`

Until you download the real file, a small synthetic sample with the same
schema is included at `data/sample_transactions.csv` so you can run and test
the whole pipeline immediately.

## 2. Setup

```bash
python -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -r requirements.txt
```

## 3. Run the pipeline

```bash
# 1. Clean + engineer features
python src/prepare_data.py --input data/transactions.csv --output data/processed.csv

# 2. Train the model (saves models/model.pkl + prints metrics)
python src/train_model.py --input data/processed.csv

# 3. Launch the live app
streamlit run src/app.py
```

If you haven't downloaded the real CSV yet, swap `data/transactions.csv`
for `data/sample_transactions.csv` in step 1 to test the pipeline end to end.

## 4. Make it live (public URL for your CV)

**Easiest: Streamlit Community Cloud (free)**
1. Push this folder to a public GitHub repo (include `models/model.pkl`
   after training, or retrain via a build step — see note in `app.py`).
2. Go to https://share.streamlit.io, connect your GitHub, pick the repo,
   set main file to `src/app.py`.
3. Deploy. You'll get a URL like `yourname-dubai-property.streamlit.app`
   — put this directly on your CV/LinkedIn.

**Alternative: Hugging Face Spaces (also free, supports Streamlit/Gradio)**
Create a Space, choose Streamlit SDK, push the same files.

## 5. Project structure

```
dubai-property-predictor/
├── data/
│   ├── transactions.csv          # <- you add this (real DLD data)
│   └── sample_transactions.csv   # synthetic, for testing the pipeline
├── src/
│   ├── prepare_data.py           # cleaning + feature engineering
│   ├── train_model.py            # trains + evaluates + saves model
│   └── app.py                    # Streamlit live prediction app
├── models/
│   └── model.pkl                 # trained model (generated)
└── requirements.txt
```

## 6. How to talk about this on your CV / in interviews

- "Built an end-to-end ML pipeline predicting Dubai property prices from
  ~[N] real Dubai Land Department transaction records, achieving an R² of
  [X] / MAE of AED [X] on held-out data."
- Be ready to explain: why you log-transformed price (right-skewed), how
  you handled categorical explosion in `Area`/`Project` (target encoding
  or grouping rare categories), and what features mattered most
  (feature_importances_ — the script prints this).
- Mention it's live and link it. A working demo beats a GitHub repo alone.
