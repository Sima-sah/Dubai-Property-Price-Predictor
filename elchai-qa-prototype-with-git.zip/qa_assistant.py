"""
Internal Document Q&A Assistant — prototype
Elchai Group / AI Agent & OpenClaw Research Intern assessment

This script demonstrates the workflow described in the assessment report:
  Input -> AI Processing (grounded retrieval + answer) -> Output -> Pending Human Review

It ships with a lightweight MOCK model (`mock_llm`) so the demo is reproducible
without an API key. Swap in `call_claude()` (below) to use a real model —
just set ANTHROPIC_API_KEY and change `USE_MOCK = False`.

No real Elchai data is used. sample_docs/remote_work_policy.md is fictional,
built only to demonstrate the mechanics end to end.
"""

import csv
import os
import re
from datetime import datetime, timezone

USE_MOCK = True  # flip to False + set ANTHROPIC_API_KEY to call the real Claude API
LOG_PATH = "logs/interaction_log.csv"
DOC_PATH = "sample_docs/remote_work_policy.md"

GROUNDED_SYSTEM_PROMPT = (
    "Answer only using the attached document. Quote the exact clause. "
    "If a condition (cap, approval, exclusion) exists, state it. "
    "If the answer is not in the document, say so explicitly and do not guess."
)


def load_doc(path: str) -> str:
    with open(path, "r") as f:
        return f.read()


def retrieve_sections(doc_text: str, query: str) -> str:
    """Very small keyword-based retrieval — splits the doc into '## Section' chunks
    and returns the ones whose text overlaps with query keywords. A production
    version would use embeddings/vector search or Claude's long-context window
    to read the whole document directly instead of chunking."""
    chunks = re.split(r"(?=^## )", doc_text, flags=re.MULTILINE)
    keywords = [w.lower() for w in re.findall(r"[a-zA-Z]{4,}", query)]
    scored = []
    for chunk in chunks:
        score = sum(chunk.lower().count(k) for k in keywords)
        if score > 0:
            scored.append((score, chunk))
    scored.sort(key=lambda x: -x[0])
    return "\n".join(c for _, c in scored[:2]) if scored else ""


def mock_llm(query: str, context: str, grounded: bool) -> str:
    """Deterministic stand-in for the model, tuned to reproduce the exact
    ungrounded-fail / grounded-fix example described in the written assessment."""
    q = query.lower()

    if "co-working" in q or "coworking" in q:
        if grounded and context:
            return (
                "Yes — up to AED 500/month, but only if you work remotely more than "
                "3 days/week and your line manager pre-approves it (Section 4.2). "
                "Home internet/utilities are explicitly excluded."
            )
        return "Yes, you can expense your co-working space membership."  # naive, incomplete

    if "internet" in q or "utilit" in q:
        return "Not reimbursable — Section 4.2 explicitly excludes home internet and utility costs."

    if "leave" in q or "vacation" in q:
        return "Not covered in the provided document. Please check the HR Leave Policy or ask HR directly."

    return "I don't have enough information in the provided document to answer that confidently."


def call_claude(query: str, context: str) -> str:
    """Real integration point (not used in this offline demo).
    pip install anthropic; export ANTHROPIC_API_KEY=...
    """
    import anthropic  # noqa: F401 (left as a reference implementation)

    client = anthropic.Anthropic()
    msg = client.messages.create(
        model="claude-sonnet-4-6",
        max_tokens=500,
        system=GROUNDED_SYSTEM_PROMPT,
        messages=[{"role": "user", "content": f"Document:\n{context}\n\nQuestion: {query}"}],
    )
    return msg.content[0].text


def ensure_log():
    os.makedirs("logs", exist_ok=True)
    if not os.path.exists(LOG_PATH):
        with open(LOG_PATH, "w", newline="") as f:
            csv.writer(f).writerow(
                ["timestamp_utc", "model_tool", "grounded", "prompt", "output", "reviewer_status"]
            )


def log_interaction(model_tool, grounded, prompt, output, reviewer_status):
    ensure_log()
    with open(LOG_PATH, "a", newline="") as f:
        csv.writer(f).writerow(
            [datetime.now(timezone.utc).isoformat(timespec="seconds"), model_tool,
             grounded, prompt, output, reviewer_status]
        )


def ask(query: str, grounded: bool, reviewer_status: str = "Pending Human Review"):
    doc = load_doc(DOC_PATH)
    context = retrieve_sections(doc, query) if grounded else doc  # ungrounded pass ignores retrieval discipline
    answer = mock_llm(query, context, grounded) if USE_MOCK else call_claude(query, context)
    model_tool = "Claude Sonnet 5 (mock demo)" if USE_MOCK else "Claude Sonnet 5 (live API)"
    print(f"\nQ: {query}")
    print(f"[{'grounded' if grounded else 'UNGROUNDED'}] A: {answer}")
    print(f"Status: {reviewer_status}")
    log_interaction(model_tool, grounded, query, answer, reviewer_status)
    return answer


if __name__ == "__main__":
    print("=== Elchai Internal Document Q&A — prototype demo ===")

    # Query 1: first pass, ungrounded — reproduces the failure described in the report
    ask("Can I expense my co-working space membership?", grounded=False,
        reviewer_status="Rejected - missing conditions")

    # Query 2: same question, fixed with grounded retrieval + instruction
    ask("Can I expense my co-working space membership?", grounded=True,
        reviewer_status="Approved by reviewer")

    # Query 3: correctly-excluded item
    ask("Can I expense my home internet bill?", grounded=True,
        reviewer_status="Approved by reviewer")

    # Query 4: out-of-scope — model should decline rather than guess
    ask("What is the parental leave policy?", grounded=True,
        reviewer_status="Approved - routed to HR for real answer")

    print(f"\nFull log written to {LOG_PATH}")
