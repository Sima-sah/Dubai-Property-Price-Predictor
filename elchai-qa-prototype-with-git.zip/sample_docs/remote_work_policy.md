# Remote Work & Expense Policy (v3, SAMPLE — fictional, for demo purposes only)

## Section 4.1 — Eligibility
Employees may work remotely up to 5 days per week with manager approval, provided role
requirements (client-facing, on-site, or lab-based roles excluded) allow it.

## Section 4.2 — Co-working Space Expense
Employees working remotely more than 3 days/week may expense a co-working space
membership up to **AED 500/month**, subject to **line-manager pre-approval**.
Home internet and home utility costs are **not reimbursable**.

## Section 4.3 — Equipment
Company laptops and a one-time AED 300 home-office setup allowance are provided to
employees approved for remote work under Section 4.1.

## Section 5.1 — Leave Requests
Leave requests are covered under the separate HR Leave Policy (not included in this
document). This assistant should say "not covered" rather than guess if asked about leave.
