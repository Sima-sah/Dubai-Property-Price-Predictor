# Elchai Internal Document Q&A — Prototype

Pre-interview assessment prototype for the **AI Agent & OpenClaw Research Intern** role.
Full written report (tool comparison, risks, recommendation) is in the accompanying PDF/DOCX:
`Elchai_AI_Agent_Assessment.pdf`.

## What this demonstrates

A minimal, runnable version of the proposed workflow:

```
Input (employee question) -> AI Processing (grounded retrieval + answer)
   -> Output (answer + citation) -> Pending Human Review -> logged
```

It reproduces the exact "fail then fix" example from the report:

1. **Ungrounded prompt** — the model answers "yes" without checking the AED 500 cap
   or the manager pre-approval condition. Flagged and rejected by the reviewer.
2. **Grounded prompt** — with a system instruction that forces citation and explicit
   gap-flagging, the same question gets a complete, correctly-sourced answer.
3. A question **outside the document's scope** (parental leave) is correctly declined
   rather than guessed at, and routed to HR.

## Repo contents

| Path | Purpose |
|---|---|
| `qa_assistant.py` | Runnable demo: retrieval + Q&A + CSV audit log |
| `sample_docs/remote_work_policy.md` | Fictional sample policy doc used for grounding (no real Elchai data was available) |
| `ui/chat_view.html`, `ui/log_dashboard.html` | Front-end mockups used to produce the screenshots below |
| `screenshots/` | Rendered screenshots of the chat flow, reviewer log, and terminal run |
| `logs/interaction_log.csv` | Sample audit log produced by running the script |

## Run it

```bash
python3 qa_assistant.py
```

No API key required — it ships with a small deterministic mock model (`mock_llm`) so
the demo is reproducible offline. To connect a real model, set `USE_MOCK = False` in
`qa_assistant.py`, `pip install anthropic`, export `ANTHROPIC_API_KEY`, and it will call
`call_claude()` instead (already implemented, just unused by default).

## Screenshots

- `screenshots/01_chat_view.png` — employee-facing chat: ungrounded failure vs. grounded fix
- `screenshots/02_log_dashboard.png` — reviewer-facing audit log
- `screenshots/03_terminal_run.png` — the script actually running end to end

## What this is *not*

- Not connected to any real Elchai system or document — the sample policy is fictional,
  built only to demonstrate the mechanics.
- Not a production RAG pipeline — retrieval here is a simple keyword match over a
  single short document; a real deployment would use Claude's long-context window or a
  vector store for larger document sets, plus proper access control per the risk
  section of the written report.
- Not legal/compliance advice — see the written report's limitations section (UAE PDPL,
  data residency, etc. still need sign-off from Elchai's legal/compliance function).

## Known limitations

- Mock model responses are hard-coded for the four demo questions to keep the exercise
  reproducible without an API key; they are not a general-purpose Q&A engine yet.
- No authentication/access-control layer is implemented — a real pilot needs
  role-based document scoping before going anywhere near sensitive data.
- Logging here is a local CSV for demo purposes; production would write to a
  proper database with retention rules matching Elchai's record-keeping policy.
